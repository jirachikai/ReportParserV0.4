1.Please install 'tornado-3.1.1.tar.gz' first, this is the server lib.
2.You can run 'server.py' to set up server for access.
3.'main.vi' is report parser, it will be added into windows scheduler.